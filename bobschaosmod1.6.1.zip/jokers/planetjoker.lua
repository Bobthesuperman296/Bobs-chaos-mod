SMODS.Joker{ --Planet joker
    key = "planetjoker",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Planet joker',
        ['text'] = {
            [1] = 'If you reach youre last hand',
            [2] = 'this joker creates a random {C:common}Planet{} card'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.current_round.hands_left == 1 then
            end
        end
    end
}