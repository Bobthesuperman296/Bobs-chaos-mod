SMODS.Enhancement {
    key = 'enchanted',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            x_mult = 2
        }
    },
    loc_txt = {
        name = 'Enchanted',
        text = {
        [1] = 'Gives {X:red,C:white}2X{} {C:red}Mult{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = false,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_mult = card.ability.extra.x_mult }
        end
    end
}