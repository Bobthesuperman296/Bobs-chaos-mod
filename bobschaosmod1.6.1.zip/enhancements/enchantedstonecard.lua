SMODS.Enhancement {
    key = 'enchantedstonecard',
    pos = { x = 3, y = 0 },
    config = {
        bonus = 50,
        extra = {
            x_mult = 1.5
        }
    },
    loc_txt = {
        name = 'Enchanted stone card',
        text = {
        [1] = 'Gives {C:blue}50 chips{} and {X:red,C:white}1.5X{} {C:red}Mult{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = true,
    no_rank = true,
    no_suit = true,
    always_scores = true,
    unlocked = true,
    discovered = false,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_mult = card.ability.extra.x_mult }
        end
    end
}