SMODS.ConsumableType {
    key = 'wierd_set',
    primary_colour = HEX('ea1b1b'),
    secondary_colour = HEX('ea1b1b'),
    collection_rows = { 4, 5 },
    shop_rate = 1,
    cards = {
        ['c_bobschao_something'] = true
    },
    loc_txt = {
        name = "Wierd set",
        collection = "Wierd set Cards",
    }
}

SMODS.ConsumableType {
    key = 'random_set',
    primary_colour = HEX('8b572a'),
    secondary_colour = HEX('8b572a'),
    collection_rows = { 4, 5 },
    shop_rate = 1,
    cards = {
        ['c_bobschao_randomconsumable'] = true,
        ['c_bobschao_randomjokers'] = true,
        ['c_bobschao_randomplanet'] = true,
        ['c_bobschao_randomspectral'] = true,
        ['c_bobschao_randomtarot'] = true
    },
    loc_txt = {
        name = "Random set",
        collection = "Random set Cards",
    }
}