SMODS.Seal {
    key = 'instantwin',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            odds = 10,
            mult = 10000000000000000000
        }
    },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Instant win',
        label = 'Instant win',
        text = {
        [1] = 'When hand is scored, 1 in 10 chance to give',
        [2] = '{C:red}10,000,000,000,000,000,000 mult{}'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_ea5cd3aa', 1, card.ability.seal.extra.odds, 'm_bobschao_instantwin') then
                SMODS.calculate_effect({mult = card.ability.seal.extra.mult}, card)
            end
        end
    end
}