SMODS.Seal {
    key = 'redpurpleseal',
    pos = { x = 4, y = 0 },
    config = {
        extra = {
            retrigger_times = 1,
            x_mult = 1.5
        }
    },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Red+purple seal',
        label = 'Red+purple seal',
        text = {
        [1] = 'Retriggers card and gives {X:red,C:white}1.5X{} {C:red}Mult{}'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = false,
    no_collection = false,
    calculate = function(self, card, context)
        if context.repetition and card.should_retrigger then
            return { repetitions = card.ability.seal.extra.retrigger_times }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_retrigger = false
            card.should_retrigger = true
            SMODS.calculate_effect({x_mult = card.ability.seal.extra.x_mult}, card)
        end
    end
}