SMODS.Seal {
    key = 'randomseal',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            odds = 4,
            retrigger_times = 1,
            x_mult = 1.5,
            dollars = 10
        }
    },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Random seal',
        label = 'Random seal',
        text = {
        [1] = '{C:green}1 in 4{} chance to re-trigger card',
        [2] = '{C:green}1 in 4{} chance to give {X:red,C:white}1.5X{} {C:red}mult{}',
        [3] = '{C:green}1 in 4{} chance to give {C:attention}$10{}',
        [4] = '{C:green}1 in 4{} chance to give last played {C:planet}planet{} card',
        [5] = ''
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.repetition and card.should_retrigger then
            return { repetitions = card.ability.seal.extra.retrigger_times }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_retrigger = false
            if SMODS.pseudorandom_probability(card, 'group_0_acbf5cbe', 1, card.ability.seal.extra.odds, 'm_bobschao') then
                card.should_retrigger = true
            end
            if SMODS.pseudorandom_probability(card, 'group_1_a39644a5', 1, card.ability.seal.extra.odds, 'm_bobschao') then
                SMODS.calculate_effect({x_mult = card.ability.seal.extra.x_mult}, card)
            end
            if SMODS.pseudorandom_probability(card, 'group_2_56e0d056', 1, card.ability.seal.extra.odds, 'm_bobschao') then
                SMODS.calculate_effect({dollars = lenient_bignum(card.ability.seal.extra.dollars)}, card)
            end
            if SMODS.pseudorandom_probability(card, 'group_3_dc7e466c', 1, card.ability.seal.extra.odds, 'm_bobschao') then
                G.E_MANAGER:add_event(Event({
                trigger = 'before',
                delay = 0.0,
                func = function()
                    if G.GAME.last_hand_played then
                        local _planet = nil
                        for k, v in pairs(G.P_CENTER_POOLS.Planet) do
                            if v.config.hand_type == G.GAME.last_hand_played then
                                _planet = v.key
                            end
                        end
                        if _planet then
                            local planet_card = SMODS.add_card({ key = _planet })
                            planet_card:set_edition("e_negative", true)
                        end
                        
                    end
                    return true
                end
            }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_planet'), colour = G.C.SECONDARY_SET.Planet})
            end
        end
    end
}