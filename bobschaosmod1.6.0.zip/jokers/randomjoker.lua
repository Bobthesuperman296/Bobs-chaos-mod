SMODS.Joker{ --Random Joker
    key = "randomjoker",
    config = {
        extra = {
            odds = 10,
            odds2 = 25,
            odds3 = 50,
            odds4 = 100
        }
    },
    loc_txt = {
        ['name'] = 'Random Joker',
        ['text'] = {
            [1] = 'Once blind has been selected',
            [2] = '{C:green}1 in 10{} chance to create a {C:common}Common{} joker',
            [3] = '{C:green}1 in 25{} chance to create an {C:uncommon}Uncommon{} joker',
            [4] = '{C:green}1 in 50{} chance to create a {C:rare}Rare{} joker',
            [5] = '{C:green}1 in 100{} Chance to create a {C:legendary}Legendary{} joker',
            [6] = '(all jokers that come from this joker will be negative)'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = 4,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.setting_blind  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_1afc1236', 1, card.ability.extra.odds, 'j_bobschao_randomjoker', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Common' })
                    if joker_card then
                        joker_card:set_edition("e_negative", true)
                        
                    end
                    
                    return true
                end
            }))
            
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Common", colour = G.C.BLUE})
            end
            return true
        end}, card)
          end
                if SMODS.pseudorandom_probability(card, 'group_1_8039cd35', 1, card.ability.extra.odds2, 'j_bobschao_randomjoker', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Uncommon' })
                    if joker_card then
                        joker_card:set_edition("e_negative", true)
                        
                    end
                    
                    return true
                end
            }))
            
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Uncommon", colour = G.C.BLUE})
            end
            return true
        end}, card)
          end
                if SMODS.pseudorandom_probability(card, 'group_2_ea220bc4', 1, card.ability.extra.odds3, 'j_bobschao_randomjoker', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Rare' })
                    if joker_card then
                        joker_card:set_edition("e_negative", true)
                        
                    end
                    
                    return true
                end
            }))
            
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Rare!", colour = G.C.BLUE})
            end
            return true
        end}, card)
          end
                if SMODS.pseudorandom_probability(card, 'group_3_745b035c', 1, card.ability.extra.odds4, 'j_bobschao_randomjoker', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Legendary' })
                    if joker_card then
                        joker_card:set_edition("e_negative", true)
                        
                    end
                    
                    return true
                end
            }))
            
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "LEGENDARY!!!", colour = G.C.BLUE})
            end
            return true
        end}, card)
          end
            end
        end
    end
}