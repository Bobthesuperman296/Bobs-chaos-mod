SMODS.Seal {
    key = 'errorseal',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Error Seal',
        label = 'Error Seal',
        text = {
        [1] = 'Creates a random {C:tarot}tarot{} card if card scores'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = false,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Tarot', edition = 'e_negative', key_append = 'enhanced_card_tarot'}
                        return true
                    end
                }))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_consumable and "+1 Consumable!" or nil, colour = G.C.PURPLE})
        end
    end
}