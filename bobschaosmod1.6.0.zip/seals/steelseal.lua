SMODS.Seal {
    key = 'steelseal',
    pos = { x = 5, y = 0 },
    config = {
        extra = {
            x_mult = 3
        }
    },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Steel seal',
        label = 'Steel seal',
        text = {
        [1] = 'Gives {X:red,C:white}3X{} {C:red}Mult{} if held in hand'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = false,
    no_collection = false,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            return { x_mult = card.ability.seal.extra.x_mult }
        end
    end
}