SMODS.Consumable {
    key = 'nil',
    set = 'Tarot',
    pos = { x = 0, y = 0 },
    config = { extra = {
        odds = 1000,
        dollars_value = 1000000
    } },
    loc_txt = {
        name = 'Nil',
        text = {
        [1] = '{C:green}1 in 1000{} chance to get {C:attention}$1,000,000{}'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = false,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            if SMODS.pseudorandom_probability(card, 'group_0_39a50cf1', 1, card.ability.extra.odds, 'c_bobschao_nil', false) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1000000).." $", colour = G.C.MONEY})
                    ease_dollars(1000000, true)
                    return true
                end
            }))
            delay(0.6)
            end
    end,
    can_use = function(self, card)
        return true
    end
}