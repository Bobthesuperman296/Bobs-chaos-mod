SMODS.ConsumableType {
    key = 'wierd_set',
    primary_colour = HEX('ea1b1b'),
    secondary_colour = HEX('ea1b1b'),
    collection_rows = { 4, 5 },
    shop_rate = 1,
    cards = {
        ['c_bobschao_something'] = true
    },
    loc_txt = {
        name = "Wierd set",
        collection = "Wierd set Cards",
    }
}