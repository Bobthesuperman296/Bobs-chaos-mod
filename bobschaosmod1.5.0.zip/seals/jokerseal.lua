SMODS.Seal {
    key = 'jokerseal',
    pos = { x = 2, y = 0 },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Joker Seal',
        label = 'Joker Seal',
        text = {
        [1] = 'Gives a random Negative joker when discarded'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.discard and context.other_card == card then
            local created_joker = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'Joker' })
                        if joker_card then
                            joker_card:set_edition("e_negative", true)
                            
                        end
                        
                        return true
                    end
                }))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
        end
    end
}