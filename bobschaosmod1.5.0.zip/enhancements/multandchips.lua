SMODS.Enhancement {
    key = 'multandchips',
    pos = { x = 3, y = 0 },
    config = {
        mult = 20,
        bonus = 50
    },
    loc_txt = {
        name = 'Mult and chips',
        text = {
        [1] = 'Gives {C:red}20 mult{} and {C:blue}50 chips{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = false,
    no_collection = false,
    weight = 5
}