SMODS.Joker{ --Error
    key = "error",
    config = {
        extra = {
            odds = 10,
            odds2 = 20
        }
    },
    loc_txt = {
        ['name'] = 'Error',
        ['text'] = {
            [1] = 'When you discard',
            [2] = '1 in 10 chance that you will get {C:gold}$10{}',
            [3] = '1 in 20 chance that it will self destruct'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.pre_discard  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_1_e2b1858a', 1, card.ability.extra.odds2, 'j_bobschao_error') then
                      SMODS.calculate_effect({func = function()
                card:start_dissolve()
                return true
            end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Bye XD", colour = G.C.RED})
                  end
            end
        end
    end
}